# DWL
Daily Work Load - Written almost entirely by ChatGPT


This project was started with the use of ChatGPT.

It designed and created most of these files.

I've only assembled the pieces. Enjoy!

There are a few bugs in this code. 


Warning ----------

Sandbox is turned OFF

This will create a folder in your Documents folder called:

DailyWorkLoad


Any files there will be clobbered.


Also you have to grant privilages to the app once compiled to allow the app to control your computer.

Control Panel => Privacy & Security => Accessability has to be enabled for the App.

The reports is a little buggy. You have to wait at least ten - fifteen minutes for app use to accumalate and maybe run the report twice for data to export.


If you feel like working on this project, let me know. Would like to have it a lot better.


-Neo
