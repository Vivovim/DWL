//
//  DailyWorkLoadApp.swift
//  Daily Work Load
//
//  Created by Christopher Huffaker on 4/10/25.
//


import SwiftUI

struct DailyWorkLoadApp: App {
   

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
