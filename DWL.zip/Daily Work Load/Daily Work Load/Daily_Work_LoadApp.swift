//
//  Daily_Work_LoadApp.swift
//  Daily Work Load
//
//  Created by Christopher Huffaker on 4/10/25.
//

import SwiftUI

@main
struct Daily_Work_LoadApp: App {
    
    @NSApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                    
        }
    }
}


// there was the problem.
